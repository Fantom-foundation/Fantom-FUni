<template>
    <div class="ballot-form">
        <f-card class="f-card-double-padding">
            <f-form center-form @f-form-submit="onFormSubmit">
                <fieldset class="f-data-layout">
                    <legend class="h2">
                        Polls <span class="f-steps"><b>1</b> / 2</span>
                    </legend>

                    <!--
                    <div class="row no-collapse">
                        <div class="col-3 f-row-label">Name</div>
                        <div class="col break-word">
                            <template v-if="ballot.detailsUrl">
                                <a :href="ballot.detailsUrl" target="_blank">{{ ballot.name }}</a>
                            </template>
                            <template v-else>
                                {{ ballot.name }}
                            </template>
                        </div>
                    </div>

                    <div class="row no-collapse">
                        <div class="col-3 f-row-label">Proposals</div>
                        <div class="col break-word">
                            <ul class="no-markers" aria-label="list of proposals">
                                <li v-for="(item, index) in ballot.proposals" :key="`bltprop${index}`">
                                    <label class="option small">
                                        <input v-model="proposal" type="radio" name="proposal" :value="index" />
                                        <span class="radio"></span> {{ item }}
                                    </label>
                                </li>
                            </ul>
                        </div>
                    </div>
-->
                    <div class="form-body">
                        <h2 class="align-center">
                            {{ ballot.name }} <br />
                            <span v-if="ballot.detailsUrl" class="more-info">
                                <a :href="ballot.detailsUrl" target="_blank">(more info)</a>
                            </span>
                        </h2>

                        <div>
                            <ul class="no-markers" aria-label="list of proposals">
                                <li v-for="(item, index) in ballot.proposals" :key="`bltprop${index}`">
                                    <label class="option small">
                                        <input v-model="proposal" type="radio" name="proposal" :value="index" />
                                        <span class="radio"></span> {{ item }}
                                    </label>
                                </li>
                            </ul>
                            <f-message v-if="proposalErrorMsg" type="error" with-icon>{{ proposalErrorMsg }}</f-message>
                        </div>

                        <div class="align-center form-buttons">
                            <button type="button" class="btn large light" @click="onPreviousBtnClick">Previous</button>
                            <button type="submit" class="btn large">Vote</button>
                        </div>
                    </div>
                </fieldset>
            </f-form>
        </f-card>
    </div>
</template>

<script>
import FForm from '../../core/FForm/FForm.vue';
import FCard from '../../core/FCard/FCard.vue';
import FMessage from '../../core/FMessage/FMessage.vue';

export default {
    name: 'BallotForm',

    components: { FMessage, FCard, FForm },

    props: {
        /** Ballot data object. */
        ballot: {
            type: Object,
            default() {
                return {};
            },
            required: true,
        },
    },

    data() {
        return {
            proposal: -1,
            proposalErrorMsg: '',
        };
    },

    watch: {
        proposal(_newValue) {
            if (_newValue > -1) {
                this.proposalErrorMsg = '';
            }
        },
    },

    methods: {
        onFormSubmit() {
            if (this.proposal === -1) {
                this.proposalErrorMsg = 'Please select one of the options';
            } else {
                this.proposalErrorMsg = '';

                /*
                this.$emit('change-component', {
                    to: 'ballot-confirmation',
                    from: 'ballot-form',
                    data: {
                        ballot: this.ballot,
                        proposalIndex: this.proposal,
                    },
                });
*/
            }
        },

        onPreviousBtnClick() {
            this.$emit('change-component', {
                to: 'ballot-list',
                from: 'ballot-form',
            });
        },
    },
};
</script>

<style lang="scss">
@import 'style';
</style>
